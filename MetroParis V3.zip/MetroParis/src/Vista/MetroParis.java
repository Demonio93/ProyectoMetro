package Vista;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.WindowConstants;
import Vista.Ventana;

public class MetroParis {

    public static void main(String[] args) {
        new Ventana().setVisible(true);
    }
}
