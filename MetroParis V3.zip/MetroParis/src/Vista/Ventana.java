package Vista;

import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class Ventana extends JFrame {

    JLayeredPane paneles;
    JScrollPane scroll;

    public Ventana() {
        paneles = new JLayeredPane();
        this.setTitle("Metro de Paris");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        Dimension dimension = new Dimension(1364, 742);
        this.setPreferredSize(dimension);
        paneles();
        scroll = new JScrollPane();
        scroll.setViewportView(paneles);
        this.add(scroll);
    }

    private void paneles() {
        Lineas lineas = new Lineas();
        paneles.add(lineas.lblFondo, new Integer(1));
        for (int i = 0; i < lineas.estaciones.length; i++) {
            paneles.add(lineas.estaciones[i], new Integer((i + 2)));
        }
        paneles.add(lineas.ope, new Integer(303));
    }
}
