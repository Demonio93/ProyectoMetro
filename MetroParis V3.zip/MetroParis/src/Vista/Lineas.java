package Vista;

import Controlador.acciones;
import java.awt.Color;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class Lineas {

    JLabel[] estaciones;
    JLabel lblFondo;
    JPanel ope;

    public Lineas() {
        estaciones = new JLabel[301];
        lblFondo = new JLabel();
        fondo();
        estaciones();
        pocisiones();
        colorEstacion(estaciones);
        caminoMasCorto();
    }

    private void fondo() {
        lblFondo.setBounds(0, 0, 1364, 742);
        ImageIcon ImagenFondo = new ImageIcon("src/vista/plano-metro-paris.jpg");
        Icon iconoFondo = new ImageIcon(ImagenFondo.getImage().getScaledInstance(lblFondo.getWidth(), lblFondo.getHeight(),
                Image.SCALE_DEFAULT));
        lblFondo.setIcon(iconoFondo);
        lblFondo.updateUI();
    }

    private void estaciones() {
        for (int i = 0; i < estaciones.length; i++) {
            estaciones[i] = new JLabel((i + 1) + "");
            if (i < 9) {
                estaciones[i].setSize(7, 11);
            } else {
                if (i >= 9 && i < 99) {
                    estaciones[i].setSize(15, 11);
                } else {
                    if (i >= 99) {
                        estaciones[i].setSize(21, 11);
                    }
                }
            }
        }
    }

    private void pocisiones() {
        //linea 1        
        estaciones[0].setLocation(100, 190);
        estaciones[1].setLocation(180, 240);
        estaciones[2].setLocation(220, 260);
        estaciones[3].setLocation(260, 280);
        estaciones[4].setLocation(310, 300);
        estaciones[5].setLocation(350, 330);
        estaciones[6].setLocation(390, 350);
        estaciones[7].setLocation(420, 370);
        estaciones[8].setLocation(450, 390);
        estaciones[9].setLocation(520, 400);
        estaciones[10].setLocation(580, 400);
        estaciones[11].setLocation(640, 400);
        estaciones[12].setLocation(750, 400);
        estaciones[13].setLocation(810, 400);
        estaciones[14].setLocation(870, 430);
        estaciones[15].setLocation(940, 440);
        estaciones[16].setLocation(1000, 520);
        estaciones[17].setLocation(1080, 490);
        estaciones[18].setLocation(1150, 460);
        estaciones[19].setLocation(1240, 470);
        estaciones[20].setLocation(1280, 490);
        estaciones[21].setLocation(1320, 500);
        estaciones[22].setLocation(1340, 520);
        estaciones[299].setLocation(150, 220);
        estaciones[300].setLocation(120, 210);
        //linea 2
        estaciones[23].setLocation(170, 310);
        estaciones[24].setLocation(220, 340);
        estaciones[25].setLocation(340, 280);
        estaciones[26].setLocation(380, 260);
        estaciones[27].setLocation(410, 240);
        estaciones[28].setLocation(450, 220);
        estaciones[29].setLocation(490, 200);
        estaciones[30].setLocation(530, 200);
        estaciones[31].setLocation(610, 200);
        estaciones[32].setLocation(680, 200);
        estaciones[33].setLocation(750, 200);
        estaciones[34].setLocation(820, 200);
        estaciones[35].setLocation(900, 200);
        estaciones[36].setLocation(990, 200);
        estaciones[37].setLocation(1030, 220);
        estaciones[38].setLocation(1030, 250);
        estaciones[39].setLocation(1030, 280);
        estaciones[40].setLocation(1070, 300);
        estaciones[41].setLocation(1110, 320);
        estaciones[42].setLocation(1150, 350);
        estaciones[43].setLocation(1150, 380);
        estaciones[44].setLocation(1150, 410);
        estaciones[45].setLocation(1150, 440);
        //linea 3
        estaciones[46].setLocation(300, 140);
        estaciones[47].setLocation(320, 150);
        estaciones[48].setLocation(340, 160);
        estaciones[49].setLocation(360, 170);
        estaciones[50].setLocation(380, 190);
        estaciones[51].setLocation(400, 200);
        estaciones[52].setLocation(420, 210);
        estaciones[53].setLocation(480, 240);
        estaciones[54].setLocation(530, 280);
        estaciones[55].setLocation(550, 310);
        estaciones[56].setLocation(590, 330);
        estaciones[57].setLocation(620, 350);
        estaciones[58].setLocation(670, 360);
        estaciones[59].setLocation(730, 360);
        estaciones[60].setLocation(810, 360);
        estaciones[61].setLocation(900, 350);
        estaciones[62].setLocation(920, 330);
        estaciones[63].setLocation(950, 330);
        estaciones[64].setLocation(1070, 340);
        estaciones[65].setLocation(1100, 350);
        estaciones[66].setLocation(1210, 350);
        estaciones[67].setLocation(1280, 350);
        estaciones[68].setLocation(1320, 350);
        //linea 3 bis
        estaciones[69].setLocation(1250, 320);
        estaciones[70].setLocation(1280, 290);
        estaciones[71].setLocation(1290, 260);
        //linea 4
        estaciones[72].setLocation(730, 120);
        estaciones[73].setLocation(760, 140);
        estaciones[74].setLocation(780, 150);
        estaciones[75].setLocation(780, 170);
        estaciones[76].setLocation(880, 220);
        estaciones[77].setLocation(900, 250);
        estaciones[78].setLocation(860, 270);
        estaciones[79].setLocation(840, 310);
        estaciones[80].setLocation(750, 360);
        estaciones[81].setLocation(750, 380);
        estaciones[82].setLocation(730, 420);
        estaciones[83].setLocation(700, 450);
        estaciones[84].setLocation(690, 480);
        estaciones[85].setLocation(630, 470);
        estaciones[86].setLocation(610, 490);
        estaciones[87].setLocation(610, 520);
        estaciones[88].setLocation(610, 550);
        estaciones[89].setLocation(660, 550);
        estaciones[90].setLocation(690, 570);
        estaciones[91].setLocation(720, 580);
        estaciones[92].setLocation(710, 610);
        estaciones[93].setLocation(690, 640);
        estaciones[94].setLocation(670, 650);
        estaciones[95].setLocation(670, 670);
        //linea 5
        estaciones[96].setLocation(1320, 130);
        estaciones[97].setLocation(1290, 150);
        estaciones[98].setLocation(1250, 170);
        estaciones[99].setLocation(1210, 180);
        estaciones[100].setLocation(1160, 190);
        estaciones[101].setLocation(1110, 180);
        estaciones[102].setLocation(1060, 200);
        estaciones[103].setLocation(920, 290);
        estaciones[104].setLocation(980, 340);
        estaciones[105].setLocation(1010, 390);
        estaciones[106].setLocation(970, 410);
        estaciones[107].setLocation(940, 500);
        estaciones[108].setLocation(940, 540);
        estaciones[109].setLocation(940, 570);
        estaciones[110].setLocation(910, 580);
        estaciones[111].setLocation(880, 610);
        //Linea 6
        estaciones[112].setLocation(260, 340);
        estaciones[113].setLocation(210, 360);
        estaciones[114].setLocation(200, 400);
        estaciones[115].setLocation(210, 440);
        estaciones[116].setLocation(250, 470);
        estaciones[117].setLocation(290, 490);
        estaciones[118].setLocation(350, 510);
        estaciones[119].setLocation(420, 530);
        estaciones[120].setLocation(460, 550);
        estaciones[121].setLocation(510, 560);
        estaciones[122].setLocation(630, 560);
        estaciones[123].setLocation(750, 600);
        estaciones[124].setLocation(780, 620);
        estaciones[125].setLocation(840, 610);
        estaciones[126].setLocation(930, 620);
        estaciones[127].setLocation(980, 610);
        estaciones[128].setLocation(1030, 600);
        estaciones[129].setLocation(1080, 570);
        estaciones[130].setLocation(1110, 550);
        estaciones[131].setLocation(1150, 530);
        estaciones[132].setLocation(1180, 520);
        estaciones[133].setLocation(1210, 500);
        //Linea 7
        estaciones[134].setLocation(1150, 60);
        estaciones[135].setLocation(1150, 90);
        estaciones[136].setLocation(1110, 120);
        estaciones[137].setLocation(1080, 140);
        estaciones[138].setLocation(1050, 160);
        estaciones[139].setLocation(1030, 170);
        estaciones[140].setLocation(1000, 180);
        estaciones[141].setLocation(980, 230);
        estaciones[142].setLocation(950, 240);
        estaciones[143].setLocation(790, 250);
        estaciones[144].setLocation(710, 250);
        estaciones[145].setLocation(690, 270);
        estaciones[146].setLocation(620, 310);
        estaciones[147].setLocation(580, 360);
        estaciones[148].setLocation(680, 400);
        estaciones[149].setLocation(820, 430);
        estaciones[150].setLocation(860, 460);
        estaciones[151].setLocation(840, 520);
        estaciones[152].setLocation(810, 540);
        estaciones[153].setLocation(810, 560);
        estaciones[154].setLocation(840, 590);
        estaciones[155].setLocation(870, 630);
        estaciones[156].setLocation(870, 650);
        estaciones[157].setLocation(910, 660);
        estaciones[158].setLocation(960, 660);
        estaciones[159].setLocation(1020, 660);
        estaciones[160].setLocation(1050, 670);
        estaciones[161].setLocation(1080, 690);
        estaciones[162].setLocation(870, 670);
        estaciones[163].setLocation(870, 690);
        estaciones[164].setLocation(870, 710);
        estaciones[165].setLocation(870, 730);
        //Linea 7 bis
        estaciones[166].setLocation(1240, 240);
        estaciones[167].setLocation(1200, 220);
        estaciones[168].setLocation(1150, 240);
        estaciones[169].setLocation(1120, 240);
        estaciones[170].setLocation(1060, 230);
        estaciones[171].setLocation(1190, 260);
        //Linea 8
        estaciones[172].setLocation(260, 630);
        estaciones[173].setLocation(300, 610);
        estaciones[174].setLocation(330, 590);
        estaciones[175].setLocation(340, 570);
        estaciones[176].setLocation(340, 540);
        estaciones[177].setLocation(350, 470);
        estaciones[178].setLocation(380, 440);
        estaciones[179].setLocation(420, 420);
        estaciones[180].setLocation(460, 360);
        estaciones[181].setLocation(670, 310);
        estaciones[182].setLocation(720, 310);
        estaciones[183].setLocation(800, 310);
        estaciones[184].setLocation(930, 360);
        estaciones[185].setLocation(930, 390);
        estaciones[186].setLocation(930, 410);
        estaciones[187].setLocation(970, 460);
        estaciones[188].setLocation(1040, 470);
        estaciones[189].setLocation(1110, 510);
        estaciones[190].setLocation(1180, 540);
        estaciones[191].setLocation(1200, 570);
        estaciones[192].setLocation(1170, 580);
        estaciones[193].setLocation(1200, 610);
        estaciones[194].setLocation(1230, 630);
        estaciones[195].setLocation(1260, 640);
        estaciones[196].setLocation(1290, 650);
        estaciones[197].setLocation(1290, 670);
        estaciones[198].setLocation(1290, 690);
        estaciones[199].setLocation(1290, 710);
        estaciones[200].setLocation(1290, 730);
        estaciones[201].setLocation(1330, 730);
        //Linea 9
        estaciones[202].setLocation(50, 660);
        estaciones[203].setLocation(70, 640);
        estaciones[204].setLocation(90, 630);
        estaciones[205].setLocation(120, 610);
        estaciones[206].setLocation(120, 590);
        estaciones[207].setLocation(120, 570);
        estaciones[208].setLocation(120, 540);
        estaciones[209].setLocation(120, 510);
        estaciones[210].setLocation(120, 470);
        estaciones[211].setLocation(120, 440);
        estaciones[212].setLocation(140, 400);
        estaciones[213].setLocation(260, 400);
        estaciones[214].setLocation(340, 380);
        estaciones[215].setLocation(430, 330);
        estaciones[216].setLocation(470, 320);
        estaciones[217].setLocation(490, 300);
        estaciones[219].setLocation(1050, 390);
        estaciones[220].setLocation(1080, 400);
        estaciones[221].setLocation(1100, 420);
        estaciones[222].setLocation(1130, 430);
        estaciones[223].setLocation(1220, 450);
        estaciones[224].setLocation(1240, 430);
        estaciones[225].setLocation(1260, 420);
        estaciones[226].setLocation(1280, 410);
        estaciones[227].setLocation(1310, 400);
        estaciones[228].setLocation(1330, 380);
        //Linea 10
        estaciones[229].setLocation(20, 590);
        estaciones[230].setLocation(50, 570);
        estaciones[231].setLocation(150, 570);
        estaciones[232].setLocation(190, 560);
        estaciones[233].setLocation(240, 540);
        estaciones[234].setLocation(170, 540);
        estaciones[235].setLocation(80, 550);
        estaciones[237].setLocation(280, 540);
        estaciones[238].setLocation(310, 520);
        estaciones[239].setLocation(440, 540);
        estaciones[240].setLocation(490, 530);
        estaciones[241].setLocation(520, 510);
        estaciones[242].setLocation(560, 490);
        estaciones[243].setLocation(640, 480);
        estaciones[244].setLocation(730, 480);
        estaciones[245].setLocation(770, 490);
        estaciones[246].setLocation(800, 510);
        //Linea 11
        estaciones[247].setLocation(850, 380);
        estaciones[248].setLocation(990, 300);
        estaciones[249].setLocation(1080, 270);
        estaciones[250].setLocation(1140, 270);
        estaciones[251].setLocation(1240, 270);
        estaciones[252].setLocation(1330, 240);
        //Linea 12
        estaciones[253].setLocation(960, 110);
        estaciones[254].setLocation(900, 150);
        estaciones[255].setLocation(730, 160);
        estaciones[256].setLocation(690, 160);
        estaciones[257].setLocation(690, 180);
        estaciones[258].setLocation(690, 230);
        estaciones[259].setLocation(670, 260);
        estaciones[260].setLocation(590, 260);
        estaciones[261].setLocation(460, 430);
        estaciones[262].setLocation(490, 450);
        estaciones[263].setLocation(520, 470);
        estaciones[264].setLocation(590, 510);
        estaciones[265].setLocation(630, 540);
        estaciones[266].setLocation(540, 550);
        estaciones[267].setLocation(470, 590);
        estaciones[268].setLocation(430, 610);
        estaciones[269].setLocation(400, 630);
        estaciones[270].setLocation(360, 650);
        estaciones[271].setLocation(300, 680);
        estaciones[272].setLocation(270, 700);
        //Linea 13
        estaciones[218].setLocation(330, 50);
        estaciones[236].setLocation(350, 70);
        estaciones[273].setLocation(860, 10);
        estaciones[274].setLocation(840, 20);
        estaciones[275].setLocation(730, 50);
        estaciones[276].setLocation(640, 60);
        estaciones[277].setLocation(600, 80);
        estaciones[278].setLocation(560, 100);
        estaciones[279].setLocation(530, 120);
        estaciones[280].setLocation(530, 150);
        estaciones[281].setLocation(300, 20);
        estaciones[282].setLocation(400, 100);
        estaciones[283].setLocation(460, 130);
        estaciones[284].setLocation(490, 150);
        estaciones[285].setLocation(530, 170);
        estaciones[286].setLocation(530, 230);
        estaciones[287].setLocation(420, 460);
        estaciones[288].setLocation(450, 500);
        estaciones[289].setLocation(600, 590);
        estaciones[290].setLocation(580, 610);
        estaciones[291].setLocation(540, 630);
        estaciones[292].setLocation(500, 650);
        estaciones[293].setLocation(460, 680);
        estaciones[294].setLocation(430, 690);
        estaciones[295].setLocation(400, 710);
        //Linea 14
        estaciones[296].setLocation(1100, 600);
        estaciones[297].setLocation(1070, 620);
        estaciones[298].setLocation(1000, 630);
    }

    public void colorEstacion(JLabel [] estaciones) {
        for (int i = 0; i < estaciones.length; i++) {
            estaciones[i].setForeground(Color.white);
            estaciones[i].setOpaque(true);
            if (i < 23 || i == 299 || i == 300) {//linea 1
                estaciones[i].setBackground(new Color(convHex("f6ca0c")));
            } else {
                if (i >= 23 && i < 46) {//linea 2
                    estaciones[i].setBackground(new Color(convHex("135fb5")));
                } else {
                    if (i >= 46 && i < 69) {//linea 3
                        estaciones[i].setBackground(new Color(convHex("979421")));
                    } else {
                        if (i >= 69 && i < 72) {//linea 3 bis
                            estaciones[i].setBackground(new Color(convHex("7fd0e1")));
                        } else {
                            if (i >= 72 && i < 96) {//linea 4
                                estaciones[i].setBackground(new Color(convHex("c3499c")));
                            } else {
                                if (i >= 96 && i < 112) {//linea 5
                                    estaciones[i].setBackground(new Color(convHex("f98d45")));
                                } else {
                                    if (i >= 112 && i < 134) {//linea 6
                                        estaciones[i].setBackground(new Color(convHex("71c490")));
                                    } else {
                                        if (i >= 134 && i < 166) {//linea 7
                                            estaciones[i].setBackground(new Color(convHex("f9a1b9")));
                                        } else {
                                            if (i >= 166 && i < 172) {//linea 7 bis
                                                estaciones[i].setBackground(new Color(convHex("6dc48f")));
                                            } else {
                                                if (i >= 172 && i < 202) {//linea 8
                                                    estaciones[i].setBackground(new Color(convHex("cfa6d0")));
                                                } else {
                                                    if (i >= 202 && i < 229 && i != 218) {//linea 9
                                                        estaciones[i].setBackground(new Color(convHex("d0cb00")));
                                                    } else {
                                                        if (i >= 229 && i < 247 && i != 236) {//linea 10
                                                            estaciones[i].setBackground(new Color(convHex("e7b84c")));
                                                        } else {
                                                            if (i >= 247 && i < 253) {//linea 11
                                                                estaciones[i].setBackground(new Color(convHex("89592b")));
                                                            } else {
                                                                if (i >= 253 && i < 273) {//linea 12
                                                                    estaciones[i].setBackground(new Color(convHex("008351")));
                                                                } else {
                                                                    if (i >= 273 && i < 296 || i == 218 || i == 236) {//linea 13
                                                                        estaciones[i].setBackground(new Color(convHex("88d5e7")));
                                                                    } else {
                                                                        if (i >= 296 && i < 299) {//linea 14
                                                                            estaciones[i].setBackground(new Color(convHex("5e008a")));
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
    }

    private int convHex(String hex) {
        return Integer.parseInt(hex, 16);
    }

    private void caminoMasCorto() {
        ope = new JPanel();
        ope.setBounds(0, 0, 270, 70);
        ope.setLayout(null);

        JSpinner spinners[] = new JSpinner[2];
        JButton botones[] = new JButton[2];

        spinners[0] = new JSpinner(new SpinnerNumberModel(1, 1, 301, 1));
        spinners[1] = new JSpinner(new SpinnerNumberModel(1, 1, 301, 1));
        botones[0] = new JButton("Ruta");
        botones[1] = new JButton("Limpiar");

        spinners[0].setBounds(10, 25, 40, 20);
        spinners[1].setBounds(60, 25, 40, 20);
        botones[0].setBounds(110, 25, 60, 20);
        botones[1].setBounds(180, 25, 80, 20);

        ope.add(spinners[0]);
        ope.add(spinners[1]);
        ope.add(botones[0]);
        ope.add(botones[1]);
        
        new acciones(estaciones, spinners, botones);
    }
}
