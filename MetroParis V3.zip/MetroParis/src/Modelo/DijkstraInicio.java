package Modelo;

import java.util.*;
import javax.swing.JLabel;

public class DijkstraInicio {

    public void Inicio(int inicial, int fin, JLabel[] arreglo) {
        int A, origen=0, destino=0, peso=0, V;
        Scanner sc = new Scanner(System.in);      //para lectura de datos

        V = 301;
        A = 714;
        String archivo = new archivo().abrirArchivo();

        int[][] matriz = new CrearMatriz(archivo).crearMatriz();

        Dijkstra dijkstraAlgorithm = new Dijkstra(V);
        for (int i = 0; i < A; i++) {
            for (int j = 0; j < 3; j++) {
                switch (j) {
                    case 0:
                        origen = matriz[i][j];
                        break;
                    case 1:
                        destino = matriz[i][j];
                        break;
                    case 2:
                        peso = matriz[i][j];
                        break;
                }
            }
            dijkstraAlgorithm.addEdge(origen, destino, peso, true);
        }

        dijkstraAlgorithm.dijkstra(inicial);
        dijkstraAlgorithm.printShortestPath(fin, arreglo);
    }
}
