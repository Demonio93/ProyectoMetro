package Modelo;

public class CrearMatriz {
    private String cadena;
    private int [][] matrizChida;
    
    public CrearMatriz(String cadena){
        this.cadena=cadena;
    }
    
    public int [][] crearMatriz(){
        String [] arreglo=cadena.split("-");
        matrizChida=new int[arreglo.length][3];
        
        for (int i = 0; i < arreglo.length; i++) {
            String [] arreglo2=arreglo[i].split(",");
            for (int j = 0; j < 3; j++) {
                matrizChida[i][j]=Integer.parseInt(arreglo2[j]);
            }
        }
        
        return matrizChida;
    }
}
