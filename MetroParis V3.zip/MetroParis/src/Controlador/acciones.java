
package Controlador;

import Modelo.DijkstraInicio;
import Vista.Lineas;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSpinner;

public class acciones implements ActionListener {

    JLabel[] estaciones;
    JSpinner[] spiners;
    JButton[] botones;

    public acciones(JLabel[] estaciones, JSpinner[] spiners, JButton[] botones) {
        this.botones = botones;
        this.spiners = spiners;
        this.estaciones = estaciones;

        botones[0].addActionListener(this);
        botones[1].addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == botones[0]) {
            new Lineas().colorEstacion(estaciones);
            new DijkstraInicio().Inicio(
                    Integer.parseInt(spiners[0].getValue().toString()),
                    Integer.parseInt(spiners[1].getValue().toString()),
                    estaciones);
            estaciones[Integer.parseInt(spiners[0].getValue().toString())-1].setBackground(Color.MAGENTA);
            estaciones[Integer.parseInt(spiners[1].getValue().toString())-1].setBackground(Color.MAGENTA);
        } else {
            if (ae.getSource() == botones[1]) {
                new Lineas().colorEstacion(estaciones);
            }
        }
    }

}
